﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Project
{
    public class ImgItem : BaseItem
    {
        public static int Count { get; set; }
    }
}
